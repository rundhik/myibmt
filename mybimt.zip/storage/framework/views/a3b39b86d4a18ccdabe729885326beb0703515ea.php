<?php $__env->startSection('judul', 'Jadwal Kuliah'); ?>

<?php $__env->startSection('konten'); ?>
    
<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver-desktop m-grid--desktop 	m-container m-container--responsive m-container--xxl m-page__container m-body">
    <div class="m-grid__item m-grid__item--fluid m-wrapper">

        <div class="m-content">

            <!--Begin::Section-->
            <div class="row">
                <div class="col-xl-12">
                    
                    <!--begin::Portlet-->
                    <div class="m-portlet m-portlet--mobile">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($subheader); ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__body">

                            <!--begin: Datatable -->
                            <table class="table table-striped- table-bordered table-hover table-checkable" id="matakuliah">
                                <thead>
                                    <tr>
                                        <th>Mata Kuliah</th>
                                        <th>Kelas</th>
                                        <th>Dosen</th>
                                        <th>Ruangan</th>
                                        <th>Hari</th>
                                        <th>Jam</th>
                                        <th>Peserta</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                      
                                        <td><?php echo e(MyIBMT\Models\MataKuliah::find($data->find($d->id)->kelasperkuliahan->matakuliah_id)->nm_matakuliah); ?></td>
                                        <td><?php echo e($d->nm_kelas); ?></td>
                                        <td><?php echo e(MyIBMT\Models\Dosen::find($d->dosen_id)->nm_dosen); ?></td>
                                        <td><?php echo e(MyIBMT\Models\RuangPerkuliahan::find($d->ruang_id)->nm_ruangan); ?></td>
                                        <td><?php echo e($d->hari); ?></td>
                                        <td><?php echo e($d->jam); ?></td>
                                        <td><?php echo e($d->jml_peserta); ?></td>
                                        <?php if( $d->status == 1): ?>
                                            <td>Sedang Perkuliahan</td>
                                        <?php elseif( $d->status == 0): ?>
                                            <td>Selesai</td>
                                        <?php else: ?>
                                            <td>Terjadwal</td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Mata Kuliah</th>
                                        <th>Kelas</th>
                                        <th>Dosen</th>
                                        <th>Ruangan</th>
                                        <th>Hari</th>
                                        <th>Jam</th>
                                        <th>Peserta</th>
                                        <th>Status</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                    </div>
                    <!--end::Portlet-->

                </div>
            </div>

            <!--End::Section-->

        </div>
    </div>
</div>

<!-- end::Body -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('jadwal'); ?>
<script>
    $("#jadwal").DataTable({
        scrollY:"30vh",
        crollX:!0,
        scrollCollapse:!0,
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.apps', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>