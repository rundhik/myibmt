<?php $__env->startSection('judul', 'Kelas Perkuliahan'); ?>

<?php $__env->startSection('konten'); ?>
    
<!-- begin::Body -->
<div class="m-grid__item m-grid__item--fluid  m-grid m-grid--ver-desktop m-grid--desktop 	m-container m-container--responsive m-container--xxl m-page__container m-body">
    <div class="m-grid__item m-grid__item--fluid m-wrapper">

        <div class="m-content">

            <!--Begin::Section-->
            <div class="row">
                <div class="col-xl-12">
                    
                    <!--begin::Portlet-->
                    <div class="m-portlet m-portlet--mobile">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($subheader); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <ul class="m-portlet__nav">
                                    <li class="m-portlet__nav-item">
                                        <form action="<?php echo e(route('kelas.create')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('GET'); ?>
                                            <input type="hidden" value="<?php echo e($prd); ?>" name="prodi_id">
                                            <input type="hidden" value="<?php echo e($smt); ?>" name="thn_semester_id">
                                            <input type="hidden" value="1" name="kurikulum">
                                            <button type="submit" class="btn btn-focus m-btn m-btn--custom m-btn--pill m-btn--icon m-btn--air">
                                                <span >
                                                    <i class="la la-plus"></i>
                                                    <span>Tambah</span>
                                                </span>
                                            </button>
                                        </form>
                                    </li>
                                    <li class="m-portlet__nav-item"></li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="m-portlet__body">
                            <form action="<?php echo e(route('kelas.index')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('GET'); ?>
                                <div class="m-form m-form--label-align-right m--margin-top-20 m--margin-bottom-30">
                                    <div class="row align-items-center">
                                        <div class="col-xl-12 order-2 order-xl-1">
                                            <div class="form-group m-form__group row align-items-center">
                                                <div class="col-md-3">
                                                    <div class="m-form__group m-form__group--inline">
                                                        <div class="m-form__label">
                                                            <label>Program Studi:</label>
                                                        </div>
                                                        <div class="m-form__control">
                                                            <div class="col-md-12 col-sm-12">
                                                                <select class="form-control m-input" name="prodi_id">
                                                                <option>Pilih Program Studi</option>
                                                                <?php $__currentLoopData = $filter['datakrk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($prd == $krk->id): ?>
                                                                        <option value="<?php echo e($krk->id); ?>" selected><?php echo e($krk->deskripsi); ?></option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($krk->id); ?>"><?php echo e($krk->deskripsi); ?></option> 
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="d-md-none m--margin-bottom-10"></div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="m-form__group m-form__group--inline">
                                                        <div class="m-form__label">
                                                            <label>Tahun Akademik:</label>
                                                        </div>
                                                        <div class="m-form__control">
                                                            <div class="col-md-12 col-sm-12">
                                                                <select class="form-control m-input" name="thn_semester_id">
                                                                <option selected>Pilih Tahun Akademik</option>
                                                                <?php $__currentLoopData = $filter['datathn']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($smt  == $thn->id): ?>
                                                                        <option value="<?php echo e($thn->id); ?>" selected><?php echo e($thn->deskripsi); ?></option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($thn->id); ?>"><?php echo e($thn->deskripsi); ?></option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="d-md-none m--margin-bottom-10"></div>
                                                </div>
                                                
                                                <div class="col-md-4">
                                                    <div class="m-form__group m-form__group--inline">
                                                        <div class="m-form__label">
                                                            <button type="submit" class="btn btn-primary">Refresh Data</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!--begin: Datatable -->
                            <table class="table table-striped- table-bordered table-hover table-checkable" id="kelas">
                                <thead>
                                    <tr>
                                        <th>Kurikulum</th>
                                        <th>Nama Mata Kuliah</th>
                                        <th>Semester</th>
                                        <th>SKS</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                                      
                                        <td><?php echo e(MyIBMT\Models\Kurikulum::find($d->kurikulum_id)->nm_kurikulum); ?></td>
                                        <td><?php echo e(MyIBMT\Models\MataKuliah::find($d->matakuliah_id)->nm_matakuliah); ?></td>
                                        <td><?php echo e($d->semester); ?></td>
                                        <td><?php echo e(MyIBMT\Models\MataKuliah::find($d->matakuliah_id)->sks); ?></td>
                                        <td>
                                            <a class="m-portlet__nav-link btn m-btn m-btn--hover-brand m-btn--icon m-btn--icon-only m-btn--pill" href="<?php echo e(route('kelas.edit', $d->id)); ?>" title="Ubah">
                                                <i class="la la-edit"></i>
                                            </a>
                                            <a class="m-portlet__nav-link btn m-btn m-btn--hover-brand m-btn--icon m-btn--icon-only m-btn--pill" href="<?php echo e(route('kelas.show', $d->id)); ?>" title="Hapus">
                                                <i class="la la-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Kurikulum</th>
                                        <th>Nama Mata Kuliah</th>
                                        <th>Semester</th>
                                        <th>SKS</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                    </div>
                    <!--end::Portlet-->

                </div>
            </div>

            <!--End::Section-->

        </div>
    </div>
</div>

<!-- end::Body -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('kelas'); ?>
<script>
    $("#kelas").DataTable({
        scrollY:"30vh",
        crollX:!0,
        scrollCollapse:!0,
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>